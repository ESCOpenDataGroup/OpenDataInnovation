# OpenDataInnovation
open data innovation 

Open Data Source:
-----------
MyLondon, Published by Greater London Authority.<br>
https://data.gov.uk/dataset/mylondon<br>

London Borough Profiles and Atlas, Published by Greater London Authority.<br>
https://data.gov.uk/dataset/london-borough-profiles-and-atlas<br>

London Empty Homes Audit, Published by Greater London Authority.<br>
https://data.gov.uk/dataset/london-empty-homes-audit<br>


JavaScript Library:
-----------
Fast and powerful CSV (delimited text) parser that gracefully handles large files and malformed input.<br>
https://github.com/mholt/PapaParse<br>
D3<br>
https://github.com/d3/d3<br>
Bootstrat<br>
JQuery<br>
Google Map<br>

crawler Framework
-----------
Scrapy<br>

Server framework and Library
------------
C# .NET MVC
